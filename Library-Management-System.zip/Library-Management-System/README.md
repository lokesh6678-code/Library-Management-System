# Library Management System

A simple Java console application for managing a small collection of library books.

## Features
- Add a book with an ID, title, and author
- Display all books and their availability
- Search for a book by ID
- Borrow an available book
- Return a borrowed book
- Prevent duplicate book IDs and invalid borrow/return actions

## Technology
- Java
- ArrayList
- Scanner
- Object-oriented programming

## How to run
1. Install a JDK.
2. Open a terminal in this folder.
3. Compile: `javac LibraryManagementSystem.java`
4. Run: `java LibraryManagementSystem`

Note: This beginner project stores book records in memory, so records reset when the program exits.
