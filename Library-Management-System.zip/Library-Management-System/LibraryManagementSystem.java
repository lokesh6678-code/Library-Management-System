import java.util.ArrayList;
import java.util.Scanner;

class Book {
    int id;
    String title;
    String author;
    boolean borrowed;

    Book(int id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.borrowed = false;
    }
}

public class LibraryManagementSystem {
    private static final ArrayList<Book> books = new ArrayList<>();
    private static final Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;

        do {
            System.out.println("\n===== LIBRARY MANAGEMENT SYSTEM =====");
            System.out.println("1. Add book");
            System.out.println("2. View all books");
            System.out.println("3. Search book by ID");
            System.out.println("4. Borrow book");
            System.out.println("5. Return book");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            while (!input.hasNextInt()) {
                System.out.print("Please enter a number: ");
                input.next();
            }
            choice = input.nextInt();
            input.nextLine();

            switch (choice) {
                case 1 -> addBook();
                case 2 -> viewBooks();
                case 3 -> searchBook();
                case 4 -> borrowBook();
                case 5 -> returnBook();
                case 6 -> System.out.println("Thank you for using the system!");
                default -> System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 6);

        input.close();
    }

    private static void addBook() {
        System.out.print("Enter book ID: ");
        int id = readInt();

        if (findBook(id) != null) {
            System.out.println("A book with this ID already exists.");
            return;
        }

        System.out.print("Enter book title: ");
        String title = input.nextLine();

        System.out.print("Enter author name: ");
        String author = input.nextLine();

        books.add(new Book(id, title, author));
        System.out.println("Book added successfully.");
    }

    private static void viewBooks() {
        if (books.isEmpty()) {
            System.out.println("No books available.");
            return;
        }

        System.out.println("\nID\tTitle\t\tAuthor\t\tStatus");
        for (Book book : books) {
            System.out.println(book.id + "\t" + book.title + "\t\t"
                    + book.author + "\t\t"
                    + (book.borrowed ? "Borrowed" : "Available"));
        }
    }

    private static void searchBook() {
        System.out.print("Enter book ID to search: ");
        int id = readInt();
        Book book = findBook(id);

        if (book == null) {
            System.out.println("Book not found.");
        } else {
            System.out.println("ID: " + book.id);
            System.out.println("Title: " + book.title);
            System.out.println("Author: " + book.author);
            System.out.println("Status: " + (book.borrowed ? "Borrowed" : "Available"));
        }
    }

    private static void borrowBook() {
        System.out.print("Enter book ID to borrow: ");
        Book book = findBook(readInt());

        if (book == null) {
            System.out.println("Book not found.");
        } else if (book.borrowed) {
            System.out.println("This book is already borrowed.");
        } else {
            book.borrowed = true;
            System.out.println("Book borrowed successfully.");
        }
    }

    private static void returnBook() {
        System.out.print("Enter book ID to return: ");
        Book book = findBook(readInt());

        if (book == null) {
            System.out.println("Book not found.");
        } else if (!book.borrowed) {
            System.out.println("This book was not borrowed.");
        } else {
            book.borrowed = false;
            System.out.println("Book returned successfully.");
        }
    }

    private static Book findBook(int id) {
        for (Book book : books) {
            if (book.id == id) {
                return book;
            }
        }
        return null;
    }

    private static int readInt() {
        while (!input.hasNextInt()) {
            System.out.print("Please enter a valid number: ");
            input.next();
        }
        int value = input.nextInt();
        input.nextLine();
        return value;
    }
}
